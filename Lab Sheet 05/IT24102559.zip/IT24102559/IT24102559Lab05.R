setwd("C:\Users\amara\OneDrive - Sri Lanka Institute of Information Technology\SLIIT\2Y 1S\Probaility and Statistics\Labs\Lab 05")
data <-read.table("Exercise - Lab 05.txt",header = TRUE, sep = ",")
fix (data)
attach(data)
